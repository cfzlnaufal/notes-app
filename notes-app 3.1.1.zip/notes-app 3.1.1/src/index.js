import "./styles/style.css";

// Data catatan dari API
let notesData = [];

// Fungsi untuk mendapatkan catatan dari API
async function fetchNotes() {
  try {
    // Menampilkan indikator loading sebelum memulai permintaan
    showLoadingIndicator();

    const response = await fetch("https://notes-api.dicoding.dev/v2/notes");
    const data = await response.json();
    notesData = data.data;
    renderNoteList();

    // Menyembunyikan indikator loading setelah permintaan selesai
    hideLoadingIndicator();
  } catch (error) {
    console.error("Error fetching notes:", error);
    hideLoadingIndicator();
  }
}

// Fungsi untuk membuat catatan baru dan mengirimnya ke API
async function createNote(title, body) {
  try {
    const response = await fetch("https://notes-api.dicoding.dev/v2/notes", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title,
        body,
      }),
    });
    const data = await response.json();
    if (response.ok) {
      notesData.push(data.data);
      renderNoteList();
    } else {
      console.error("Failed to create note:", data.message);
    }
  } catch (error) {
    console.error("Error creating note:", error);
  }
}

// Fungsi untuk menghapus catatan dari API
async function deleteNote(noteId) {
  try {
    const response = await fetch(
      `https://notes-api.dicoding.dev/v2/notes/${noteId}`,
      {
        method: "DELETE",
      }
    );
    const data = await response.json();
    if (response.ok) {
      notesData = notesData.filter((note) => note.id !== noteId);
      renderNoteList();
    } else {
      console.error("Failed to delete note:", data.message);
    }
  } catch (error) {
    console.error("Error deleting note:", error);
  }
}

// Menampilkan indikator loading
function showLoadingIndicator() {
  const loadingIndicator = document.getElementById("loading-indicator");
  loadingIndicator.style.display = "flex";
}

// Menyembunyikan indikator loading
function hideLoadingIndicator() {
  const loadingIndicator = document.getElementById("loading-indicator");
  loadingIndicator.style.display = "none";
}

// Fungsi untuk merender daftar catatan
function renderNoteList() {
  const noteListContainer = document.createElement("div");
  noteListContainer.classList.add("grid-container");

  notesData.forEach((note) => {
    const noteCard = document.createElement("div");
    noteCard.classList.add("note-card");
    noteCard.innerHTML = `
      <h2>${note.title}</h2>
      <p>${note.body}</p>
      <small>${new Date(note.createdAt).toLocaleString()}</small>
      <button class="delete-btn" data-id="${note.id}">Delete</button>
    `;
    noteCard.querySelector(".delete-btn").addEventListener("click", () => {
      deleteNote(note.id);
    });
    noteListContainer.appendChild(noteCard);
  });

  const noteListElement = document.querySelector("note-list");
  noteListElement.innerHTML = "";
  noteListElement.appendChild(noteListContainer);
}

// Komponen web
class AppHeader extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <header>
        <h1>Notes App</h1>
      </header>
    `;
  }
}

class NoteForm extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <form id="noteForm">
        <input type="text" id="noteTitle" placeholder="Title" required>
        <textarea id="noteBody" placeholder="Body" rows="4" required style="resize: none;"></textarea>
        <button type="submit">Add Note</button>
      </form>
    `;

    // Membuat Catatan Baru
    this.querySelector("#noteForm").addEventListener("submit", (event) => {
      event.preventDefault();

      const title = document.getElementById("noteTitle").value;
      const body = document.getElementById("noteBody").value;

      createNote(title, body);

      // Reset form setelah terinput
      document.getElementById("noteTitle").value = "";
      document.getElementById("noteBody").value = "";
    });
  }
}

class NoteList extends HTMLElement {
  connectedCallback() {
    fetchNotes();
  }
}

// Mendefinisikan custom element
customElements.define("app-header", AppHeader);
customElements.define("note-form", NoteForm);
customElements.define("note-list", NoteList);
